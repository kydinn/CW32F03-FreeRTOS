示例目的：
          演示普通GPIO口PA00的定时翻转。

硬件资源：
          1. CW32F030CxTx StarKit  
          2. 时钟HSI
          3. 系统时钟默认为HSI时钟6分频，8MHz， PCLK、HCLK不分频，PCLK=HCLK=SysClk=8MHz

演示说明：
        采用默认时钟配置，PA00配置为推挽输出，在主函数中每10ms对PA00的输出电平进行翻转，利用示波器观察PA00的波形情况。

使用说明：
+ EWARM
          1. 打开project.eww文件
          2. 编译所有文件：Project->Rebuild all
          3. 载入工程镜像：Project->Debug
          4. 运行程序：Debug->Go(F5)

+ MDK-ARM
          1. 打开systick_delay.uvproj文件
          2. 编译所有文件：Project->Rebuild all target files
          3. 载入工程镜像：Debug->Start/Stop Debug Session
          4. 运行程序：Debug->Run(F5)
